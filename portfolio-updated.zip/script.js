(function(){
  "use strict";

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isTouch = window.matchMedia('(hover:none)').matches;
  var isMobile = window.innerWidth < 860;
  var isLowPower = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || isMobile;

  /* ================= Loader ================= */
  window.addEventListener('load', function(){
    setTimeout(function(){
      document.getElementById('loader').classList.add('hidden');
      var heroInner = document.querySelector('.hero-inner');
      if(heroInner) heroInner.classList.add('hero-reveal');
    }, 1300);
  });

  /* ================= Hero glow follows the cursor ================= */
  (function(){
    var heroInner = document.querySelector('.hero-inner');
    var heroSection = document.querySelector('.hero');
    if(!heroInner || !heroSection || isTouch) return;
    heroSection.addEventListener('mousemove', function(e){
      var r = heroSection.getBoundingClientRect();
      var px = ((e.clientX - r.left) / r.width) * 100;
      var py = ((e.clientY - r.top) / r.height) * 100;
      heroInner.style.setProperty('--mx', px + '%');
      heroInner.style.setProperty('--my', py + '%');
    });
  })();

  /* ================= Custom cursor ================= */
  /* Precision dot (fast, exact tracking) + trailing ring that eases behind it,
     magnetically snaps toward buttons/links, tilts in 3D off pointer velocity,
     compresses on click, and morphs into a text-beam over editable fields. */
  if(!isTouch){
    var dot = document.getElementById('cursor-dot');
    var ring = document.getElementById('cursor-ring');

    var mouseX=0, mouseY=0, lastX=0, lastY=0;
    var dotX=0, dotY=0, ringX=0, ringY=0;
    var velX=0, velY=0, tiltX=0, tiltY=0;
    var curDotScale=1, curRingScale=1, targetDotScale=1, targetRingScale=1;
    var magnetEl=null, cursorState='idle', hasMoved=false;

    var MAGNETIC_SEL = '.btn, .nav-cta, .code-run, .social-btn';
    var HOVER_SEL = 'a, button, [data-tilt], .skill-object, .gh-stat, .focus-card';
    var TEXT_SEL = 'input, textarea, [contenteditable]';
    var NAV_SEL = '.nav';

    function applyCursorState(){
      dot.classList.remove('beam');
      ring.classList.remove('hide-ring');
      if(cursorState === 'magnet'){ targetDotScale=0.35; targetRingScale=1.6; ring.classList.add('active'); }
      else if(cursorState === 'hover'){ targetDotScale=1; targetRingScale=1.35; ring.classList.add('active'); }
      else if(cursorState === 'text'){ targetDotScale=1; targetRingScale=1; ring.classList.remove('active'); ring.classList.add('hide-ring'); dot.classList.add('beam'); }
      else{ targetDotScale=1; targetRingScale=1; ring.classList.remove('active'); }
    }
    applyCursorState();

    window.addEventListener('mousemove', function(e){
      mouseX = e.clientX; mouseY = e.clientY;
      if(!hasMoved){
        hasMoved = true;
        dotX = ringX = lastX = mouseX; dotY = ringY = lastY = mouseY;
        dot.style.opacity = '1'; ring.style.opacity = '1';
      }
    });

    window.addEventListener('mousedown', function(){
      dot.classList.add('press'); ring.classList.add('press');
      targetDotScale *= 1.7; targetRingScale *= 0.6;
    });
    window.addEventListener('mouseup', function(){
      dot.classList.remove('press'); ring.classList.remove('press');
      applyCursorState();
    });

    function matches(el, sel){ return el && el.closest ? el.closest(sel) : null; }

    document.addEventListener('mouseover', function(e){
      if(matches(e.target, NAV_SEL)){
        dot.style.opacity = '0'; ring.style.opacity = '0';
        return;
      }
      var mag = matches(e.target, MAGNETIC_SEL);
      var txt = !mag && matches(e.target, TEXT_SEL);
      var hov = !mag && !txt && matches(e.target, HOVER_SEL);
      if(mag){ magnetEl = mag; cursorState = 'magnet'; applyCursorState(); }
      else if(txt){ magnetEl = null; cursorState = 'text'; applyCursorState(); }
      else if(hov){ magnetEl = null; cursorState = 'hover'; applyCursorState(); }
    }, true);

    document.addEventListener('mouseout', function(e){
      var to = e.relatedTarget;
      var leavingNav = matches(e.target, NAV_SEL) && !matches(to, NAV_SEL);
      if(leavingNav && hasMoved){ dot.style.opacity = '1'; ring.style.opacity = '1'; }
      var stillMagnet = magnetEl && to && magnetEl.contains(to);
      if(magnetEl && !stillMagnet){
        magnetEl.style.transform = '';
        magnetEl = null;
      }
      var stillActive = to && to.closest && (to.closest(MAGNETIC_SEL) || to.closest(HOVER_SEL) || to.closest(TEXT_SEL));
      if(!stillActive){ cursorState = 'idle'; applyCursorState(); }
    }, true);

    (function loopCursor(){
      var vx = mouseX-lastX, vy = mouseY-lastY;
      lastX = mouseX; lastY = mouseY;
      velX += (vx-velX)*0.25;
      velY += (vy-velY)*0.25;

      // precision dot: fast, near-instant follow
      dotX += (mouseX-dotX)*0.35;
      dotY += (mouseY-dotY)*0.35;

      // ring target: snaps toward the hovered control's center (magnetic),
      // otherwise trails the raw pointer
      var ringTargetX = mouseX, ringTargetY = mouseY;
      if(magnetEl && !reduceMotion){
        var r = magnetEl.getBoundingClientRect();
        var ecx = r.left + r.width/2, ecy = r.top + r.height/2;
        ringTargetX = ecx + (mouseX-ecx)*0.25;
        ringTargetY = ecy + (mouseY-ecy)*0.25;
      }
      ringX += (ringTargetX-ringX)*0.16;
      ringY += (ringTargetY-ringY)*0.16;

      curDotScale += (targetDotScale-curDotScale)*0.25;
      curRingScale += (targetRingScale-curRingScale)*0.2;

      dot.style.transform = 'translate3d(' + dotX + 'px,' + dotY + 'px,0) translate(-50%,-50%) scale(' + curDotScale.toFixed(3) + ')';

      if(!reduceMotion){
        var maxTilt = 9;
        var tX = Math.max(-maxTilt, Math.min(maxTilt, -velY*1.8));
        var tY = Math.max(-maxTilt, Math.min(maxTilt, velX*1.8));
        tiltX += (tX-tiltX)*0.15;
        tiltY += (tY-tiltY)*0.15;
        ring.style.transform = 'translate3d(' + ringX + 'px,' + ringY + 'px,0) translate(-50%,-50%) perspective(360px) rotateX(' + tiltX.toFixed(2) + 'deg) rotateY(' + tiltY.toFixed(2) + 'deg) scale(' + curRingScale.toFixed(3) + ')';
      } else {
        ring.style.transform = 'translate3d(' + ringX + 'px,' + ringY + 'px,0) translate(-50%,-50%) scale(' + curRingScale.toFixed(3) + ')';
      }

      requestAnimationFrame(loopCursor);
    })();
  } else {
    document.body.classList.add('no-fancy-cursor');
  }

  /* ================= Nav ================= */
  var burger = document.getElementById('burger');
  var navLinks = document.getElementById('navLinks');
  var navBackdrop = document.getElementById('navBackdrop');
  var navClose = document.getElementById('navClose');

  /* header.nav has backdrop-filter, which creates a containing block for
     position:fixed descendants (per spec). That trapped the mobile drawer
     and its backdrop inside the ~50px-tall header instead of the viewport,
     squashing the drawer panel. Moving both to be direct children of
     <body> lets their `position:fixed` resolve against the real viewport.
     IDs are unchanged so every listener below still works. */
  document.body.appendChild(navBackdrop);
  document.body.appendChild(navLinks);

  function openMenu(){
    burger.classList.add('open');
    navLinks.classList.add('open');
    navBackdrop.classList.add('open');
    document.body.classList.add('nav-open');
  }
  function closeMenu(){
    burger.classList.remove('open');
    navLinks.classList.remove('open');
    navBackdrop.classList.remove('open');
    document.body.classList.remove('nav-open');
  }
  burger.addEventListener('click', function(){
    if(navLinks.classList.contains('open')) closeMenu(); else openMenu();
  });
  navClose.addEventListener('click', closeMenu);
  navBackdrop.addEventListener('click', closeMenu);
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') closeMenu();
  });
  document.querySelectorAll('[data-nav]').forEach(function(a){
    a.addEventListener('click', closeMenu);
  });
  var navAnchors = document.querySelectorAll('[data-nav]');
  var sectionEls = ['about','skills','projects','experience','github','neural','contact'].map(function(id){ return document.getElementById(id); });
  var navObserver = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){
        navAnchors.forEach(function(a){ a.classList.remove('active'); });
        var match = document.querySelector('[data-nav][href="#'+entry.target.id+'"]');
        if(match) match.classList.add('active');
      }
    });
  }, { rootMargin:'-45% 0px -45% 0px' });
  sectionEls.forEach(function(el){ navObserver.observe(el); });

  /* ================= Reveal on scroll ================= */
  var revealObserver = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting){ entry.target.classList.add('in-view'); }
    });
  }, { threshold:0.01, rootMargin:'0px 0px -40px 0px' });
  document.querySelectorAll('.reveal').forEach(function(el){ revealObserver.observe(el); });

  /* ================= Interactive 3D skill objects ================= */
  var SKILLS = [
    // ---- Backend ----
    { name:'Python', cat:'Backend', level:4, accent:'orange', details:'Backend services, scripting, and data-processing pipelines.' },
    { name:'C++', cat:'Backend', level:3, accent:'orange', details:'Performance-critical modules and systems-level programming.' },
    { name:'C#', cat:'Backend', level:3, accent:'orange', details:'.NET services and backend APIs for enterprise applications.' },
    { name:'ASP.NET', cat:'Backend', level:3, accent:'orange', details:'Structured, scalable backend services built on the .NET stack.' },
    { name:'Laravel', cat:'Backend', level:3, accent:'orange', details:'Elegant PHP backend development with a batteries-included framework.' },
    { name:'FastAPI', cat:'Backend', level:4, accent:'orange', details:'High-performance async Python APIs with automatic docs.' },
    { name:'REST APIs', cat:'Backend', level:5, accent:'orange', details:'Designing consistent, well-documented endpoints that scale with the product.' },
    { name:'JWT', cat:'Backend', level:4, accent:'orange', details:'Token-based authentication and secure session handling.' },
    { name:'Gemini API', cat:'Backend', level:4, accent:'orange', details:'Integrating generative AI features into real product workflows.' },
    { name:'MongoDB', cat:'Backend', level:4, accent:'orange', details:'Document-based data modeling for flexible, high-throughput apps.' },
    { name:'MySQL', cat:'Backend', level:4, accent:'orange', details:'Relational schema design, indexing, and query optimization.' },
    { name:'Database Systems', cat:'Backend', level:4, accent:'orange', details:'Schema design, normalization, and query performance across SQL and NoSQL.' },
    { name:'DSA', cat:'Backend', level:4, accent:'orange', details:'Data structures and algorithms for efficient, interview-ready problem solving.' },
    { name:'OOP', cat:'Backend', level:5, accent:'orange', details:'Object-oriented design principles applied consistently across languages.' },
    { name:'Software Engineering', cat:'Backend', level:5, accent:'orange', details:'Clean architecture, maintainable code, and disciplined delivery practices.' },
    { name:'Design Patterns', cat:'Backend', level:4, accent:'orange', details:'Reusable solutions — from MVC to Singleton — applied where they earn their keep.' },
    { name:'AI Development', cat:'Backend', level:4, accent:'orange', details:'Building features powered by LLMs and generative AI APIs.' },

    // ---- Frontend ----
    { name:'HTML', cat:'Frontend', level:5, accent:'cyan', details:'Semantic, accessible markup as the structural foundation of every build.' },
    { name:'CSS', cat:'Frontend', level:5, accent:'cyan', details:'Modern layout systems, animation, and responsive design across devices.' },
    { name:'JavaScript', cat:'Frontend', level:5, accent:'cyan', details:'Primary language for interactive, high-performance front-end and full-stack apps.' },
    { name:'TypeScript', cat:'Frontend', level:5, accent:'cyan', details:'Type-safe development across large codebases, catching errors before runtime.' },
    { name:'React', cat:'Frontend', level:5, accent:'cyan', details:'Component-driven UIs, hooks, and state management in production.' },
    { name:'Next.js', cat:'Frontend', level:5, accent:'cyan', details:'Edge-rendered pages and full-stack React applications.' },
    { name:'Tailwind', cat:'Frontend', level:5, accent:'cyan', details:'Utility-first styling for fast, consistent, maintainable interfaces.' },
    { name:'Web Development', cat:'Frontend', level:5, accent:'cyan', details:'Full-stack builds from responsive front-ends to production-ready backends.' },

    // ---- Tools & Frameworks ----
    { name:'VS Code', cat:'Tools & Frameworks', level:5, accent:'cyan', details:'Daily-driver editor tuned with extensions for a fast dev loop.' },
    { name:'GitHub', cat:'Tools & Frameworks', level:5, accent:'cyan', details:'Version control, code review workflows, and clean branching history.' },
    { name:'NPM', cat:'Tools & Frameworks', level:5, accent:'cyan', details:'Package management and scripting across JavaScript projects.' },
    { name:'Vite', cat:'Tools & Frameworks', level:4, accent:'cyan', details:'Lightning-fast dev servers and optimized production builds.' },
    { name:'Vercel', cat:'Tools & Frameworks', level:4, accent:'cyan', details:'Edge deployment and instant previews for front-end apps.' },
    { name:'Postman', cat:'Tools & Frameworks', level:4, accent:'cyan', details:'Testing, documenting, and debugging APIs before they ship.' },
    { name:'Docker', cat:'Tools & Frameworks', level:4, accent:'cyan', details:'Containerizing services for consistent builds across environments.' }
  ];

  var skillGrid = document.getElementById('skillObjects');
  if(skillGrid){
    var html = SKILLS.map(function(s, i){
      var bars = '';
      for(var b=0;b<5;b++){ bars += '<i' + (b < s.level ? ' class="on"' : '') + '></i>'; }
      var levelWord = s.level >= 5 ? 'Expert' : s.level === 4 ? 'Advanced' : 'Intermediate';
      return (
        '<div class="skill-object reveal reveal-delay-' + ((i%4)+1) + '" data-accent="' + s.accent + '" tabindex="0">' +
          '<div class="cube-stage"><div class="skill-cube">' +
            '<div class="cface cf1">' + s.name + '</div>' +
            '<div class="cface cf2">' + s.name + '</div>' +
            '<div class="cface cf3">' + s.name + '</div>' +
            '<div class="cface cf4">' + s.name + '</div>' +
            '<div class="cface cf5">' + s.name + '</div>' +
            '<div class="cface cf6">' + s.name + '</div>' +
          '</div></div>' +
          '<div class="skill-name">' + s.name + '</div>' +
          '<div class="skill-tooltip glass">' +
            '<div class="tt-cat">' + s.cat + '</div>' +
            '<div class="tt-name">' + s.name + '</div>' +
            '<div class="tt-level"><div class="lvl-bars">' + bars + '</div><span class="lvl-label">' + levelWord + '</span></div>' +
            '<div class="tt-details">' + s.details + '</div>' +
          '</div>' +
        '</div>'
      );
    }).join('');
    skillGrid.innerHTML = html;

    // entrance animation for the freshly-injected cards
    document.querySelectorAll('#skillObjects .reveal').forEach(function(el){ revealObserver.observe(el); });

    var skillObjEls = document.querySelectorAll('.skill-object');
    if(!isTouch && !reduceMotion){
      // interactive mouse-follow tilt on the cube while hovered
      skillObjEls.forEach(function(obj){
        var cube = obj.querySelector('.skill-cube');
        var stage = obj.querySelector('.cube-stage');
        stage.addEventListener('mousemove', function(e){
          var r = stage.getBoundingClientRect();
          var px = (e.clientX - r.left)/r.width - 0.5;
          var py = (e.clientY - r.top)/r.height - 0.5;
          cube.style.transform = 'rotateY(' + (px*70) + 'deg) rotateX(' + (py*-70) + 'deg) scale(1.12)';
        });
        stage.addEventListener('mouseleave', function(){ cube.style.transform = ''; });
        obj.addEventListener('mouseenter', function(){ ring && ring.classList.add('active'); });
        obj.addEventListener('mouseleave', function(){ ring && ring.classList.remove('active'); });
      });
    } else {
      // touch: tap to toggle the detail tooltip, tap elsewhere to close
      skillObjEls.forEach(function(obj){
        obj.addEventListener('click', function(e){
          var wasOpen = obj.classList.contains('touch-open');
          skillObjEls.forEach(function(o){ o.classList.remove('touch-open'); });
          if(!wasOpen){ obj.classList.add('touch-open'); e.stopPropagation(); }
        });
      });
      document.addEventListener('click', function(){
        skillObjEls.forEach(function(o){ o.classList.remove('touch-open'); });
      });
    }
  }

  /* ================= Animated timeline ================= */
  var timelineEl = document.getElementById('timeline');
  if(timelineEl){
    var timelineObserver = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting) timelineEl.classList.add('filled');
      });
    }, { threshold:0.1 });
    timelineObserver.observe(timelineEl);

    var itemObserver = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting) entry.target.classList.add('in-view');
      });
    }, { threshold:0.35 });
    document.querySelectorAll('.timeline-item').forEach(function(item){ itemObserver.observe(item); });
  }

  /* ================= GitHub stat count-up ================= */
  var statObserver = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(!entry.isIntersecting) return;
      entry.target.querySelectorAll('[data-count]').forEach(function(el){
        var target = parseInt(el.getAttribute('data-count'),10) || 0;
        var start = performance.now();
        var dur = 1200;
        function step(now){
          var p = Math.min((now-start)/dur, 1);
          var eased = 1 - Math.pow(1-p, 3);
          el.textContent = Math.round(target*eased);
          if(p < 1) requestAnimationFrame(step);
          else el.setAttribute('data-animated', '1');
        }
        requestAnimationFrame(step);
      });
      statObserver.unobserve(entry.target);
    });
  }, { threshold:0.4 });
  var statsRow = document.querySelector('.github-stats');
  if(statsRow) statObserver.observe(statsRow);

  /* ================= 3D GitHub contribution wall (real data) ================= */
  var ghWall = document.getElementById('ghWall');
  if(ghWall){
    var GH_WALL_USER = 'Abdullah-sarvar';
    var weeks = isMobile ? 26 : 46;
    var wallDays = weeks * 7;

    function renderWall(levels){
      ghWall.innerHTML = '';
      levels.forEach(function(level){
        var cell = document.createElement('div');
        cell.className = 'gh-cell';
        cell.setAttribute('data-level', level);
        cell.style.opacity = '0';
        cell.style.transition = 'opacity .5s ease';
        ghWall.appendChild(cell);
      });
      var wallObserver = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(!entry.isIntersecting) return;
          Array.prototype.forEach.call(ghWall.children, function(cell, i){
            setTimeout(function(){ cell.style.opacity = '1'; }, i*4);
          });
          wallObserver.unobserve(entry.target);
        });
      }, { threshold:0.2 });
      wallObserver.observe(ghWall);
    }

    function randomLevels(n){
      var out = [];
      for(var i=0;i<n;i++){
        var roll = Math.random();
        out.push(roll < 0.35 ? 0 : roll < 0.6 ? 1 : roll < 0.8 ? 2 : roll < 0.94 ? 3 : 4);
      }
      return out;
    }

    // Public, no-auth-required service that reads the real contribution
    // calendar off the GitHub profile page. Falls back to a random pattern
    // if it's unreachable so the section never looks broken.
    fetch('https://github-contributions-api.jogruber.de/v4/' + GH_WALL_USER + '?y=last')
      .then(function(r){ return r.ok ? r.json() : Promise.reject(r.status); })
      .then(function(data){
        if(!data || !Array.isArray(data.contributions) || !data.contributions.length) throw 0;
        var levels = data.contributions.slice(-wallDays).map(function(d){ return d.level; });
        renderWall(levels);
      })
      .catch(function(){ renderWall(randomLevels(wallDays)); });
  }

  /* ================= Live GitHub data (real API) ================= */
  /* Pulls live stats + repos from the public GitHub REST API so new repos,
     stars, and followers show up automatically without editing this file.
     Falls back silently to the static markup already in the HTML if the
     network request fails (offline, rate-limited, etc). */
  (function(){
    var GH_USER = 'Abdullah-sarvar';
    var LANG_COLORS = {
      JavaScript:'#f1e05a', TypeScript:'#3178c6', Python:'#3572A5', HTML:'#e34c26',
      CSS:'#563d7c', Blade:'#f7523f', Java:'#b07219', 'C++':'#f34b7d', 'C#':'#178600',
      PHP:'#4F5D95', Shell:'#89e051', Vue:'#41b883', Dart:'#00B4AB', Go:'#00ADD8',
      Ruby:'#701516', 'Jupyter Notebook':'#DA5B0B', Dockerfile:'#384d54', C:'#555555',
      Swift:'#F05138', Kotlin:'#A97BFF'
    };
    function langColor(l){ return LANG_COLORS[l] || '#6e767c'; }
    function esc(s){
      return String(s || '').replace(/[&<>"']/g, function(c){
        return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
      });
    }
    function setCount(el, n){
      if(!el) return;
      el.setAttribute('data-count', n);
      // If this stat has already animated in (observer fired before the
      // fetch resolved), just set the final number directly.
      if(el.getAttribute('data-animated') === '1') el.textContent = n;
    }

    fetch('https://api.github.com/users/' + GH_USER)
      .then(function(r){ return r.ok ? r.json() : Promise.reject(r.status); })
      .then(function(user){
        var stats = document.querySelectorAll('.github-stats .gh-stat .num');
        if(stats[0]) setCount(stats[0], user.public_repos || 0);
        if(stats[2]) setCount(stats[2], user.followers || 0);
        if(stats[3]) setCount(stats[3], user.following || 0);
      })
      .catch(function(){ /* keep static fallback numbers already in the HTML */ });

    fetch('https://api.github.com/users/' + GH_USER + '/repos?per_page=100&sort=pushed')
      .then(function(r){ return r.ok ? r.json() : Promise.reject(r.status); })
      .then(function(repos){
        if(!Array.isArray(repos) || !repos.length) return;

        // Stars earned = total stars across all your repos
        var totalStars = repos.reduce(function(sum, r){ return sum + (r.stargazers_count || 0); }, 0);
        var starsEl = document.querySelectorAll('.github-stats .gh-stat .num')[1];
        setCount(starsEl, totalStars);

        // Every repo, highest-starred first, falling back to most recently pushed
        var featured = repos.slice().sort(function(a, b){
          if(b.stargazers_count !== a.stargazers_count) return b.stargazers_count - a.stargazers_count;
          return new Date(b.pushed_at) - new Date(a.pushed_at);
        });

        var grid = document.querySelector('.gh-repo-grid');
        if(grid && featured.length){
          grid.innerHTML = featured.map(function(r){
            var starRow = r.stargazers_count > 0
              ? '<span class="gh-repo-stars">\u2605 ' + r.stargazers_count + '</span>' : '';
            var langRow = r.language
              ? '<div class="gh-repo-lang"><i class="lang-dot" style="background:' + langColor(r.language) + '"></i>' + esc(r.language) + '</div>'
              : '';
            return '<a class="glass gh-repo-card" href="' + r.html_url + '" target="_blank" rel="noopener noreferrer">' +
                     '<div class="gh-repo-head"><span class="gh-repo-name">' + esc(r.name) + '</span>' + starRow + '</div>' +
                     '<p class="gh-repo-desc">' + esc(r.description || 'No description provided.') + '</p>' +
                     langRow +
                   '</a>';
          }).join('');
        }

        // Top languages: count each repo's primary language (simple, no extra API calls)
        var counts = {};
        repos.forEach(function(r){ if(r.language) counts[r.language] = (counts[r.language] || 0) + 1; });
        var total = Object.keys(counts).reduce(function(s, k){ return s + counts[k]; }, 0);
        var top = Object.keys(counts).map(function(k){ return { name:k, pct: Math.round((counts[k]/total)*100) }; })
          .sort(function(a, b){ return b.pct - a.pct; }).slice(0, 4);

        var langList = document.querySelector('.gh-lang-list');
        if(langList && top.length){
          langList.innerHTML = top.map(function(l){
            var c = langColor(l.name);
            return '<div class="gh-lang-row">' +
                     '<div class="gh-lang-top"><span><i class="lang-dot" style="background:' + c + '"></i>' + esc(l.name) + '</span><span>' + l.pct + '%</span></div>' +
                     '<div class="gh-lang-bar"><div class="gh-lang-fill" style="width:' + l.pct + '%; background:' + c + '"></div></div>' +
                   '</div>';
          }).join('');
        }
      })
      .catch(function(){ /* keep the static fallback repo cards already in the HTML */ });
  })();

  /* ================= Code-block contact ================= */
  var cl1 = document.getElementById('cl-1');
  if(cl1){
    // Each code line is a list of [text, className] tokens, typed token by token
    // so syntax colors appear progressively as the line is written.
    var codeLines = [
      { el: document.getElementById('cl-1'), tokens: [
        ['// say hello and let\u2019s build something', 'cm-comment']
      ]},
      { el: document.getElementById('cl-2'), tokens: [
        ['const ', 'cm-kw'], ['contact', 'cm-fn'], [' = ', 'cm-punct'], ['require', 'cm-kw'], ['(', 'cm-punct'], ["'./ethan'", 'cm-str'], [');', 'cm-punct']
      ]},
      { el: document.getElementById('cl-4'), tokens: [
        ['contact', 'cm-fn'], ['.send', 'cm-key'], ['({', 'cm-punct']
      ]}
    ];

    var lineIdx = 0, tokenIdx = 0, charIdx = 0, activeSpan = null;
    var cursor = document.createElement('span');
    cursor.className = 'code-cursor';

    function typeCode(){
      var line = codeLines[lineIdx];
      if(!line){
        cursor.remove();
        var form = document.getElementById('codeForm');
        if(form) form.classList.add('ready');
        return;
      }
      if(cursor.parentNode !== line.el) line.el.appendChild(cursor);
      var token = line.tokens[tokenIdx];
      if(!token){
        lineIdx++; tokenIdx = 0; charIdx = 0; activeSpan = null;
        setTimeout(typeCode, 220);
        return;
      }
      if(!activeSpan){
        activeSpan = document.createElement('span');
        activeSpan.className = token[1];
        line.el.insertBefore(activeSpan, cursor);
      }
      charIdx++;
      activeSpan.textContent = token[0].slice(0, charIdx);
      if(charIdx >= token[0].length){
        tokenIdx++; charIdx = 0; activeSpan = null;
      }
      setTimeout(typeCode, 26);
    }
    setTimeout(typeCode, 350);

    var codeForm = document.getElementById('codeForm');
    var codeResult = document.getElementById('codeResult');
    if(codeForm){
      codeForm.addEventListener('submit', function(e){
        e.preventDefault();
        codeResult.textContent = '// sending\u2026';
        codeResult.className = 'code-result';
        setTimeout(function(){
          codeResult.textContent = '// 200 OK \u2014 thanks, I\u2019ll reply within 24h.';
          codeResult.className = 'code-result ok';
          codeForm.reset();
        }, 900);
      });
    }
  }

  /* ================= Rotating hero role text ================= */
  (function(){
    var roleEl = document.querySelector('#roleRotator .role-text');
    if(!roleEl) return;
    var roles = ['Software Engineer', 'Web Developer', 'AI Integration Engineer', 'Full-Stack Developer'];
    if(reduceMotion || roles.length < 2) return;
    var idx = 0;
    setInterval(function(){
      roleEl.classList.add('is-fading-out');
      setTimeout(function(){
        idx = (idx + 1) % roles.length;
        roleEl.textContent = roles[idx];
        roleEl.classList.remove('is-fading-out');
        roleEl.classList.add('is-fading-in');
        void roleEl.offsetWidth; /* force reflow so the next class removal transitions */
        roleEl.classList.remove('is-fading-in');
      }, 550);
    }, 2800);
  })();

  /* ================= Cinematic hero parallax on scroll ================= */
  var heroInner = document.querySelector('.hero-inner');
  var scrollCue = document.querySelector('.scroll-cue');
  if(heroInner && !reduceMotion){
    var parallaxTicking = false;
    function updateHeroParallax(){
      var sy = window.scrollY;
      var fade = Math.max(0, 1 - sy/520);
      heroInner.style.transform = 'translateY(' + (sy*0.22) + 'px)';
      heroInner.style.opacity = fade;
      if(scrollCue) scrollCue.style.opacity = fade;
      parallaxTicking = false;
    }
    window.addEventListener('scroll', function(){
      if(!parallaxTicking){ requestAnimationFrame(updateHeroParallax); parallaxTicking = true; }
    }, { passive:true });
    updateHeroParallax();
  }

  /* ================= Magnetic buttons (subtle cursor pull) ================= */
  if(!isTouch && !reduceMotion){
    document.querySelectorAll('.btn, .nav-cta, .code-run, .social-btn').forEach(function(el){
      el.addEventListener('mousemove', function(e){
        var r = el.getBoundingClientRect();
        var mx = (e.clientX - r.left - r.width/2) * 0.25;
        var my = (e.clientY - r.top - r.height/2) * 0.35;
        el.style.transform = 'translate(' + mx + 'px,' + my + 'px)';
      });
      el.addEventListener('mouseleave', function(){ el.style.transform = ''; });
    });
  }

  /* ================= Project card tilt ================= */
  if(!isTouch){
    document.querySelectorAll('[data-tilt]').forEach(function(card){
      card.addEventListener('mousemove', function(e){
        var r = card.getBoundingClientRect();
        var px = (e.clientX - r.left)/r.width - 0.5;
        var py = (e.clientY - r.top)/r.height - 0.5;
        card.style.transform = 'perspective(900px) rotateY('+(px*5)+'deg) rotateX('+(py*-5)+'deg) translateY(-2px)';
      });
      card.addEventListener('mouseleave', function(){ card.style.transform = ''; });
    });
  }

  /* ================= HERO 3D SCENE — Software Architecture ================= */
  /* An abstract 3D composition standing in for "software architecture":
     stacked translucent UI/API/service/data layers assemble in space,
     glowing data-path curves flow between them with traveling pulses,
     small circuit-like code lattices float around the stack, and a
     drifting particle field plus a glossy reflection floor add depth.
     Mouse position and scroll both drive the camera/rig for a cinematic,
     mouse-reactive, scroll-aware backdrop. */
  (function heroArchitectureScene(){
    var container = document.getElementById('scene-container');
    if(!container || typeof THREE === 'undefined') return;

    try{

    var CYAN_HEX = 0x6e767c, ORANGE_HEX = 0xff7a45, WHITE_HEX = 0xeaf6f8;
    var CYAN = new THREE.Color(CYAN_HEX), ORANGE = new THREE.Color(ORANGE_HEX);
    var ACCENT_CSS = {};
    ACCENT_CSS[CYAN_HEX] = '#6e767c';
    ACCENT_CSS[ORANGE_HEX] = '#ff7a45';

    var W = window.innerWidth, H = window.innerHeight;

    var scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x05070a, 0.05);

    var camera = new THREE.PerspectiveCamera(42, W / H, 0.1, 100);
    camera.position.set(0, 0.3, 11.5);

    var renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isLowPower ? 1.4 : 2));
    renderer.setSize(W, H);
    if(renderer.outputEncoding !== undefined) renderer.outputEncoding = THREE.sRGBEncoding;
    if(renderer.toneMapping !== undefined){ renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15; }
    container.appendChild(renderer.domElement);

    /* ---- cinematic lighting: cool key + cyan/orange rim lights ---- */
    scene.add(new THREE.AmbientLight(0x11202a, 0.9));
    scene.add(new THREE.HemisphereLight(0x2a5866, 0x05070a, 0.55));

    var key = new THREE.DirectionalLight(WHITE_HEX, 1.1);
    key.position.set(6, 7, 9);
    scene.add(key);

    var rimCyan = new THREE.PointLight(CYAN_HEX, 3.2, 22, 2);
    rimCyan.position.set(4.5, 3.5, 4);
    scene.add(rimCyan);

    var rimOrange = new THREE.PointLight(ORANGE_HEX, 1.8, 20, 2);
    rimOrange.position.set(-5, -2.5, -3);
    scene.add(rimOrange);

    /* ---- root rig: whole composition floats right-of-center behind the copy ---- */
    var root = new THREE.Group();
    root.position.set(isMobile ? 0 : 2.35, -0.35, 0);
    scene.add(root);

    var archGroup = new THREE.Group();
    root.add(archGroup);

    /* ---- glossy reflection floor (subtle glints, not a real reflection) ---- */
    var floorGeo = new THREE.PlaneGeometry(16, 16);
    var floorMat = new THREE.MeshPhongMaterial({
      color: 0x030405, shininess: 130, specular: 0x6e767c,
      transparent: true, opacity: 0.45, side: THREE.DoubleSide
    });
    var floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2.35;
    floor.position.set(0, -3.5, -2.2);
    root.add(floor);

    /* ---- glowing core: the "engine" the whole stack assembles around ---- */
    var coreCenterY = -1.9 + ((6 - 1) / 2) * 0.92 * 0.72;
    var coreCenterZ = -1.05;
    var coreGroup = new THREE.Group();

    var coreInner = new THREE.Mesh(
      new THREE.SphereGeometry(0.16, 16, 16),
      new THREE.MeshBasicMaterial({ color: WHITE_HEX, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending })
    );
    coreGroup.add(coreInner);

    var coreWire = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.46, 1),
      new THREE.MeshBasicMaterial({ color: CYAN_HEX, wireframe: true, transparent: true, opacity: 0.6, blending: THREE.AdditiveBlending })
    );
    coreGroup.add(coreWire);

    var ringCyan = new THREE.Mesh(
      new THREE.TorusGeometry(0.78, 0.007, 8, 72),
      new THREE.MeshBasicMaterial({ color: CYAN_HEX, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending })
    );
    ringCyan.rotation.x = Math.PI / 2.3;
    coreGroup.add(ringCyan);

    var ringOrange = new THREE.Mesh(
      new THREE.TorusGeometry(1.02, 0.006, 8, 72),
      new THREE.MeshBasicMaterial({ color: ORANGE_HEX, transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending })
    );
    ringOrange.rotation.x = Math.PI / 1.7;
    ringOrange.rotation.y = 0.4;
    coreGroup.add(ringOrange);

    coreGroup.position.set((Math.random() - 0.5) * 6, coreCenterY + (Math.random() - 0.5) * 5, coreCenterZ - 5);
    coreGroup.scale.setScalar(0.05);
    coreGroup.userData.start = {
      position: coreGroup.position.clone(),
      rotation: new THREE.Euler(0, 0, 0),
      scale: coreGroup.scale.x
    };
    coreGroup.userData.target = {
      position: new THREE.Vector3(0, coreCenterY, coreCenterZ),
      rotation: new THREE.Euler(0, 0, 0),
      scale: 1
    };
    coreGroup.userData.delay = 0.55;
    archGroup.add(coreGroup);

    /* ---- procedural "UI layer" texture: grid + abstract interface blocks ---- */
    function buildLayerTexture(accentHex, seed){
      var c = document.createElement('canvas');
      c.width = 512; c.height = 320;
      var ctx = c.getContext('2d');
      var accent = ACCENT_CSS[accentHex] || '#6e767c';

      ctx.strokeStyle = 'rgba(180,230,240,0.10)';
      ctx.lineWidth = 1;
      var gx, gy;
      for(gx = 0; gx <= c.width; gx += 32){ ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, c.height); ctx.stroke(); }
      for(gy = 0; gy <= c.height; gy += 32){ ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(c.width, gy); ctx.stroke(); }

      var rng = seed;
      function rand(){ rng = (rng * 9301 + 49297) % 233280; return rng / 233280; }

      ctx.strokeStyle = accent;
      ctx.globalAlpha = 0.85;
      var blocks = 5 + Math.floor(rand() * 4);
      var i, bw, bh, bx, by;
      for(i = 0; i < blocks; i++){
        bw = 40 + rand() * 140; bh = 14 + rand() * 46;
        bx = rand() * (c.width - bw); by = rand() * (c.height - bh);
        ctx.lineWidth = 1.4;
        ctx.strokeRect(bx, by, bw, bh);
        if(rand() > 0.5){
          ctx.fillStyle = accent; ctx.globalAlpha = 0.14;
          ctx.fillRect(bx, by, bw, bh);
          ctx.globalAlpha = 0.85;
        }
      }

      ctx.globalAlpha = 0.55;
      var j, ly, lw;
      for(j = 0; j < 10; j++){
        ly = 18 + j * 28;
        if(ly > c.height - 16) break;
        lw = 30 + rand() * 90;
        ctx.beginPath(); ctx.moveTo(16, ly); ctx.lineTo(16 + lw, ly); ctx.stroke();
      }
      ctx.globalAlpha = 1;

      var tex = new THREE.CanvasTexture(c);
      tex.needsUpdate = true;
      return tex;
    }

    /* ---- assembling stack of translucent architecture / UI layers ---- */
    var LAYER_COUNT = isLowPower ? 4 : 6;
    var LAYER_LABELS = ['UI LAYER', 'API GATEWAY', 'MICROSERVICES', 'DATABASE', 'CACHE', 'INFRA CORE'];
    var panelW = 3.4, panelH = 1.9;
    var layers = [];
    var li, lt2;

    function buildLabelSprite(text, accentHex){
      var c = document.createElement('canvas');
      c.width = 512; c.height = 96;
      var ctx = c.getContext('2d');
      var accent = ACCENT_CSS[accentHex] || '#6e767c';
      ctx.font = '600 34px "JetBrains Mono", monospace';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = accent;
      ctx.shadowBlur = 18;
      ctx.fillStyle = accent;
      ctx.globalAlpha = 0.95;
      ctx.fillText(text, 4, c.height / 2);
      var tex = new THREE.CanvasTexture(c);
      tex.needsUpdate = true;
      var sprite = new THREE.Sprite(new THREE.SpriteMaterial({
        map: tex, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false
      }));
      var scaleH = 0.32;
      sprite.scale.set(scaleH * (c.width / c.height), scaleH, 1);
      return sprite;
    }

    for(li = 0; li < LAYER_COUNT; li++){
      var t = li / (LAYER_COUNT - 1);
      var accentHex = (li % 2 === 0) ? CYAN_HEX : ORANGE_HEX;
      var w = panelW - t * 0.9, h = panelH - t * 0.4;

      var group = new THREE.Group();

      var geo = new THREE.PlaneGeometry(w, h, 1, 1);
      var backMat = new THREE.MeshPhongMaterial({
        color: 0x0d2630, transparent: true, opacity: 0.16, shininess: 90,
        specular: new THREE.Color(CYAN_HEX), side: THREE.DoubleSide, depthWrite: false
      });
      group.add(new THREE.Mesh(geo, backMat));

      var uiMat = new THREE.MeshBasicMaterial({
        map: buildLayerTexture(accentHex, li * 971 + 13), transparent: true, opacity: 0.85,
        side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false
      });
      var uiMesh = new THREE.Mesh(geo.clone(), uiMat);
      uiMesh.position.z = 0.008;
      group.add(uiMesh);

      var edges = new THREE.LineSegments(
        new THREE.EdgesGeometry(geo),
        new THREE.LineBasicMaterial({ color: accentHex, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending })
      );
      edges.scale.set(1.01, 1.03, 1);
      group.add(edges);

      var chipLabel = buildLabelSprite(LAYER_LABELS[li] || ('LAYER ' + (li + 1)), accentHex);
      chipLabel.position.set(w / 2 + 0.55, 0, 0.05);
      group.add(chipLabel);

      var targetY = -1.9 + li * 0.92;
      var targetZ = -li * 0.62;
      var targetRotY = -0.22 + li * 0.05;
      var targetRotX = 0.06;

      group.position.set((Math.random() - 0.5) * 7, targetY + (Math.random() - 0.5) * 5, targetZ - 4 - Math.random() * 3);
      group.rotation.set((Math.random() - 0.5) * 1.4, (Math.random() - 0.5) * 2.4, (Math.random() - 0.5) * 1.2);
      group.scale.setScalar(0.15);

      group.userData.start = {
        position: group.position.clone(),
        rotation: new THREE.Euler(group.rotation.x, group.rotation.y, group.rotation.z),
        scale: group.scale.x
      };
      group.userData.target = {
        position: new THREE.Vector3(0, targetY, targetZ),
        rotation: new THREE.Euler(targetRotX, targetRotY, 0),
        scale: 1
      };
      group.userData.delay = li * 0.14;

      archGroup.add(group);
      layers.push(group);
    }

    /* ---- scanning highlight sweep: a soft band of light travelling through the stack ---- */
    function buildScanTexture(){
      var c = document.createElement('canvas');
      c.width = 8; c.height = 256;
      var ctx = c.getContext('2d');
      var grad = ctx.createLinearGradient(0, 0, 0, c.height);
      grad.addColorStop(0.0, 'rgba(110,118,124,0)');
      grad.addColorStop(0.5, 'rgba(190,245,255,0.9)');
      grad.addColorStop(1.0, 'rgba(110,118,124,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, c.width, c.height);
      var tex = new THREE.CanvasTexture(c);
      tex.needsUpdate = true;
      return tex;
    }
    var scanTop = -1.9 + (LAYER_COUNT - 1) * 0.92 + 1.1;
    var scanBottom = -1.9 - 1.1;
    var scanMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(panelW + 1.6, 0.55),
      new THREE.MeshBasicMaterial({
        map: buildScanTexture(), transparent: true, opacity: 0,
        blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide
      })
    );
    scanMesh.position.set(0, scanBottom, 0.4);
    archGroup.add(scanMesh);

    /* ---- small floating "code structure" lattices (circuit-like brackets) ---- */
    function buildLatticePiece(accentHex){
      var pts = [];
      var x = 0, y = 0, nx, ny;
      var segs = 5 + Math.floor(Math.random() * 4);
      var i;
      for(i = 0; i < segs; i++){
        nx = x + (Math.random() - 0.5) * 0.9;
        ny = y + (Math.random() > 0.5 ? 0.32 : -0.32);
        pts.push(new THREE.Vector3(x, y, 0), new THREE.Vector3(nx, y, 0));
        pts.push(new THREE.Vector3(nx, y, 0), new THREE.Vector3(nx, ny, 0));
        x = nx; y = ny;
      }
      var mesh = new THREE.LineSegments(
        new THREE.BufferGeometry().setFromPoints(pts),
        new THREE.LineBasicMaterial({ color: accentHex, transparent: true, opacity: 0.55, blending: THREE.AdditiveBlending })
      );
      var nodeGeo = new THREE.SphereGeometry(0.028, 6, 6);
      var nodeMat = new THREE.MeshBasicMaterial({ color: accentHex, transparent: true, opacity: 0.9 });
      var k;
      for(k = 0; k < pts.length; k += 2){
        var node = new THREE.Mesh(nodeGeo, nodeMat);
        node.position.copy(pts[k]);
        mesh.add(node);
      }
      return mesh;
    }

    var LATTICE_COUNT = isLowPower ? 5 : 11;
    var latticePieces = [];
    var lp;
    for(lp = 0; lp < LATTICE_COUNT; lp++){
      var accent2 = lp % 2 === 0 ? CYAN_HEX : ORANGE_HEX;
      var piece = buildLatticePiece(accent2);
      var radius = 2.6 + Math.random() * 2.4;
      var angle = Math.random() * Math.PI * 2;
      var ty = -1.6 + Math.random() * 3.6;
      var tz = -1 + Math.random() * 3 + Math.sin(angle) * radius * 0.4;
      var tx = Math.cos(angle) * radius;

      piece.position.set((Math.random() - 0.5) * 10, (Math.random() - 0.5) * 8, tz - 6 - Math.random() * 3);
      piece.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
      piece.scale.setScalar(0.1);

      piece.userData.start = {
        position: piece.position.clone(),
        rotation: new THREE.Euler(piece.rotation.x, piece.rotation.y, piece.rotation.z),
        scale: piece.scale.x
      };
      piece.userData.target = {
        position: new THREE.Vector3(tx, ty, tz),
        rotation: new THREE.Euler(Math.random() * 0.6 - 0.3, Math.random() * Math.PI, Math.random() * 0.4 - 0.2),
        scale: 0.7 + Math.random() * 0.6
      };
      piece.userData.delay = 0.3 + Math.random() * 0.9;
      piece.userData.floatOffset = Math.random() * Math.PI * 2;

      archGroup.add(piece);
      latticePieces.push(piece);
    }

    /* ---- data paths: glowing curves flowing between layers, with traveling pulses ---- */
    var DATA_PATH_COUNT = isLowPower ? 3 : 7;
    var dataPaths = [];
    var dp;
    for(dp = 0; dp < DATA_PATH_COUNT; dp++){
      var fromLayer = Math.floor(Math.random() * LAYER_COUNT);
      var toLayer = Math.min(LAYER_COUNT - 1, fromLayer + 1 + Math.floor(Math.random() * 2));
      var fY = -1.9 + fromLayer * 0.92, fZ = -fromLayer * 0.62;
      var tY = -1.9 + toLayer * 0.92, tZ = -toLayer * 0.62;
      var midX = (Math.random() - 0.5) * 3.2;

      var p0 = new THREE.Vector3((Math.random() - 0.5) * 2.4, fY + 0.2, fZ);
      var p1 = new THREE.Vector3(midX, (fY + tY) / 2, (fZ + tZ) / 2 + 0.6);
      var p2 = new THREE.Vector3((Math.random() - 0.5) * 2.4, tY - 0.2, tZ);
      var curve = new THREE.CatmullRomCurve3([p0, p1, p2]);

      var accent3 = dp % 2 === 0 ? CYAN_HEX : ORANGE_HEX;
      var tubeMesh = new THREE.Mesh(
        new THREE.TubeGeometry(curve, 32, 0.008, 6, false),
        new THREE.MeshBasicMaterial({ color: accent3, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false })
      );
      archGroup.add(tubeMesh);

      var pulse = new THREE.Mesh(
        new THREE.SphereGeometry(0.045, 8, 8),
        new THREE.MeshBasicMaterial({ color: accent3, transparent: true, opacity: 0, blending: THREE.AdditiveBlending })
      );
      archGroup.add(pulse);

      dataPaths.push({ curve: curve, tube: tubeMesh, pulse: pulse, speed: 0.14 + Math.random() * 0.12, offset: Math.random(), delay: 0.9 + dp * 0.1 });
    }

    /* ---- drifting particle dust field ---- */
    var PARTICLE_COUNT = isLowPower ? 220 : 650;
    var pGeo = new THREE.BufferGeometry();
    var positions = new Float32Array(PARTICLE_COUNT * 3);
    var pColors = new Float32Array(PARTICLE_COUNT * 3);
    var speeds = new Float32Array(PARTICLE_COUNT);
    var pi, pc;
    for(pi = 0; pi < PARTICLE_COUNT; pi++){
      positions[pi * 3]     = (Math.random() - 0.5) * 16;
      positions[pi * 3 + 1] = (Math.random() - 0.5) * 11;
      positions[pi * 3 + 2] = (Math.random() - 0.5) * 12 - 2;
      pc = Math.random() > 0.55 ? CYAN : (Math.random() > 0.5 ? ORANGE : new THREE.Color(0xdff2f6));
      pColors[pi * 3] = pc.r; pColors[pi * 3 + 1] = pc.g; pColors[pi * 3 + 2] = pc.b;
      speeds[pi] = 0.03 + Math.random() * 0.08;
    }
    pGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    pGeo.setAttribute('color', new THREE.BufferAttribute(pColors, 3));
    var particles = new THREE.Points(pGeo, new THREE.PointsMaterial({
      size: 0.028, vertexColors: true, transparent: true, opacity: 0.55,
      blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true
    }));
    root.add(particles);

    /* ---- occasional comet streaks crossing the background, for cinematic flair ---- */
    function buildComet(accentHex){
      var group = new THREE.Group();
      var head = new THREE.Mesh(
        new THREE.SphereGeometry(0.05, 8, 8),
        new THREE.MeshBasicMaterial({ color: accentHex, transparent: true, opacity: 0, blending: THREE.AdditiveBlending })
      );
      group.add(head);
      var cCol = new THREE.Color(accentHex);
      var trailGeo = new THREE.BufferGeometry();
      trailGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([0, 0, 0, -1.1, 0, 0]), 3));
      trailGeo.setAttribute('color', new THREE.BufferAttribute(new Float32Array([cCol.r, cCol.g, cCol.b, 0, 0, 0]), 3));
      var trail = new THREE.Line(trailGeo, new THREE.LineBasicMaterial({
        vertexColors: true, transparent: true, opacity: 0, blending: THREE.AdditiveBlending
      }));
      group.add(trail);
      group.userData.head = head;
      group.userData.trail = trail;
      group.userData.active = false;
      group.userData.timer = 1.5 + Math.random() * 5;
      return group;
    }

    function spawnComet(comet){
      var dir = new THREE.Vector3((Math.random() - 0.5), -(0.35 + Math.random() * 0.35), (Math.random() - 0.5) * 0.5).normalize();
      comet.position.set((Math.random() - 0.5) * 6, 4.5 + Math.random() * 1.5, (Math.random() - 0.5) * 5);
      comet.quaternion.setFromUnitVectors(new THREE.Vector3(1, 0, 0), dir);
      comet.userData.dir = dir;
      comet.userData.speed = 4.5 + Math.random() * 3;
      comet.userData.life = 0;
      comet.userData.maxLife = 1.6 + Math.random() * 0.9;
      comet.userData.active = true;
    }

    var COMET_COUNT = isLowPower ? 0 : 3;
    var comets = [];
    var cmi;
    for(cmi = 0; cmi < COMET_COUNT; cmi++){
      var comet = buildComet(cmi % 2 === 0 ? CYAN_HEX : ORANGE_HEX);
      root.add(comet);
      comets.push(comet);
    }

    /* ---- soft lens-flare glows at the rim light positions (fakes bloom, no postprocessing) ---- */
    function buildFlareTexture(){
      var c = document.createElement('canvas');
      c.width = 128; c.height = 128;
      var ctx = c.getContext('2d');
      var grad = ctx.createRadialGradient(64, 64, 0, 64, 64, 64);
      grad.addColorStop(0, 'rgba(255,255,255,0.9)');
      grad.addColorStop(0.4, 'rgba(255,255,255,0.25)');
      grad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, c.width, c.height);
      var tex = new THREE.CanvasTexture(c);
      tex.needsUpdate = true;
      return tex;
    }
    var flareTex = buildFlareTexture();
    var flareCyan = new THREE.Sprite(new THREE.SpriteMaterial({
      map: flareTex, color: CYAN_HEX, transparent: true, opacity: 0.55,
      blending: THREE.AdditiveBlending, depthWrite: false
    }));
    flareCyan.position.copy(rimCyan.position);
    flareCyan.scale.setScalar(2.6);
    scene.add(flareCyan);

    var flareOrange = new THREE.Sprite(new THREE.SpriteMaterial({
      map: flareTex, color: ORANGE_HEX, transparent: true, opacity: 0.4,
      blending: THREE.AdditiveBlending, depthWrite: false
    }));
    flareOrange.position.copy(rimOrange.position);
    flareOrange.scale.setScalar(2.2);
    scene.add(flareOrange);

    /* ---- interaction state: mouse parallax + scroll-driven camera dolly ---- */
    var mx = 0, my = 0;
    window.addEventListener('mousemove', function(e){
      mx = (e.clientX / window.innerWidth - 0.5) * 2;
      my = (e.clientY / window.innerHeight - 0.5) * 2;
    }, { passive: true });

    var scrollProgress = 0;
    function updateScroll(){
      var heroH = window.innerHeight || 1;
      scrollProgress = Math.min(1.4, (window.scrollY || 0) / heroH);
    }
    window.addEventListener('scroll', updateScroll, { passive: true });
    updateScroll();

    var lastResizeW = window.innerWidth;
    function onResize(){
      var w = window.innerWidth, h = window.innerHeight;
      /* Mobile browsers fire resize when the address bar shows/hides while
         scrolling, changing only height. Skip the expensive re-render setup
         in that case so scrolling stays smooth. */
      if(w === lastResizeW) return;
      lastResizeW = w;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
      root.position.x = w < 860 ? 0 : 2.35;
    }
    var resizeRAF = null;
    window.addEventListener('resize', function(){
      if(resizeRAF) cancelAnimationFrame(resizeRAF);
      resizeRAF = requestAnimationFrame(onResize);
    }, { passive: true });

    /* ---- assembly + render loop ---- */
    var clock = new THREE.Clock();
    var curRotX = 0, curRotY = 0;

    function easeOutCubic(x){ return 1 - Math.pow(1 - x, 3); }

    function applyTransform(obj, e){
      var s = obj.userData.start, tg = obj.userData.target;
      obj.position.set(
        s.position.x + (tg.position.x - s.position.x) * e,
        s.position.y + (tg.position.y - s.position.y) * e,
        s.position.z + (tg.position.z - s.position.z) * e
      );
      obj.rotation.set(
        s.rotation.x + (tg.rotation.x - s.rotation.x) * e,
        s.rotation.y + (tg.rotation.y - s.rotation.y) * e,
        s.rotation.z + (tg.rotation.z - s.rotation.z) * e
      );
      obj.scale.setScalar(s.scale + (tg.scale - s.scale) * e);
    }

    function animate(){
      requestAnimationFrame(animate);
      if(document.hidden) return;

      var dt = clock.getDelta();
      var elapsed = clock.elapsedTime;

      layers.forEach(function(g){
        var lt = Math.max(0, Math.min(1, (elapsed - g.userData.delay) / 1.7));
        var e = easeOutCubic(lt);
        applyTransform(g, e);
        if(lt >= 1){ g.position.y += Math.sin(elapsed * 0.5 + g.userData.delay * 3) * 0.045; }
      });

      latticePieces.forEach(function(p){
        var lt = Math.max(0, Math.min(1, (elapsed - p.userData.delay) / 1.7));
        var e = easeOutCubic(lt);
        applyTransform(p, e);
        if(lt >= 1){
          p.rotation.y += 0.0025;
          p.position.y += Math.sin(elapsed * 0.4 + p.userData.floatOffset) * 0.02;
        }
      });

      dataPaths.forEach(function(path){
        var lt = Math.max(0, Math.min(1, (elapsed - path.delay) / 1.2));
        path.tube.material.opacity = 0.28 * lt;
        var pt = (elapsed * path.speed + path.offset) % 1;
        path.pulse.position.copy(path.curve.getPointAt(pt));
        path.pulse.material.opacity = 0.95 * lt;
      });

      var lt0 = Math.max(0, Math.min(1, (elapsed - coreGroup.userData.delay) / 1.7));
      applyTransform(coreGroup, easeOutCubic(lt0));
      if(lt0 >= 1){
        coreWire.rotation.y += 0.006;
        coreWire.rotation.x += 0.0025;
        ringCyan.rotation.z += 0.004;
        ringOrange.rotation.z -= 0.003;
        var corePulse = 1 + Math.sin(elapsed * 1.4) * 0.06;
        coreInner.scale.setScalar(corePulse);
      }

      var scanProgress = (elapsed * 0.16) % 1;
      scanMesh.position.y = scanBottom + scanProgress * (scanTop - scanBottom);
      scanMesh.material.opacity = Math.sin(scanProgress * Math.PI) * 0.35;

      var breathe = 0.85 + Math.sin(elapsed * 0.8) * 0.15;
      rimCyan.intensity = 3.2 * breathe;
      rimOrange.intensity = 1.8 * (1.7 - breathe);
      flareCyan.material.opacity = 0.4 + Math.sin(elapsed * 0.8) * 0.15;
      flareOrange.material.opacity = 0.3 + Math.sin(elapsed * 0.8 + Math.PI) * 0.1;

      var posAttr = pGeo.attributes.position;
      var idx, k2;
      for(k2 = 0; k2 < PARTICLE_COUNT; k2++){
        idx = k2 * 3 + 1;
        posAttr.array[idx] += speeds[k2] * 0.016;
        if(posAttr.array[idx] > 5.5) posAttr.array[idx] = -5.5;
      }
      posAttr.needsUpdate = true;
      particles.rotation.y = elapsed * 0.01;

      comets.forEach(function(comet){
        var ud = comet.userData;
        if(!ud.active){
          ud.timer -= dt;
          if(ud.timer <= 0) spawnComet(comet);
          return;
        }
        comet.position.addScaledVector(ud.dir, ud.speed * dt);
        ud.life += dt;
        var fade = 1;
        if(ud.life < 0.25) fade = ud.life / 0.25;
        else if(ud.life > ud.maxLife - 0.35) fade = Math.max(0, (ud.maxLife - ud.life) / 0.35);
        ud.head.material.opacity = 0.95 * fade;
        ud.trail.material.opacity = 0.7 * fade;
        if(ud.life >= ud.maxLife){
          ud.active = false;
          ud.timer = 3 + Math.random() * 6;
          ud.head.material.opacity = 0;
          ud.trail.material.opacity = 0;
        }
      });

      curRotY += (mx * 0.32 - curRotY) * 0.045;
      curRotX += (-my * 0.14 - curRotX) * 0.045;
      archGroup.rotation.y = curRotY + elapsed * 0.045 + scrollProgress * 0.5;
      archGroup.rotation.x = curRotX;
      camera.position.z = 11.5 - scrollProgress * 1.1;
      camera.position.y = 0.3 + scrollProgress * 0.4;
      root.position.y = -0.35 + Math.sin(elapsed * 0.35) * 0.05;

      renderer.render(scene, camera);
    }

    if(reduceMotion){
      layers.forEach(function(g){ applyTransform(g, 1); });
      latticePieces.forEach(function(p){ applyTransform(p, 1); });
      dataPaths.forEach(function(path){
        path.tube.material.opacity = 0.28;
        path.pulse.material.opacity = 0.9;
        path.pulse.position.copy(path.curve.getPointAt(0.5));
      });
      applyTransform(coreGroup, 1);
      scanMesh.material.opacity = 0.18;
      scanMesh.position.y = (scanTop + scanBottom) / 2;
      flareCyan.material.opacity = 0.4;
      flareOrange.material.opacity = 0.3;
      archGroup.rotation.set(0.04, 0.18, 0);
      renderer.render(scene, camera);
    } else {
      animate();
    }

    }catch(err){
      if(container) container.style.display = 'none';
    }
  })();
})();
(function(){
  "use strict";
  var stage = document.querySelector('.neural-stage');
  var container = document.getElementById('neuralContainer');
  if(!stage || !container || typeof THREE === 'undefined') return;

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var isTouch = window.matchMedia('(hover:none)').matches;
  var isMobile = window.innerWidth < 860;
  var isLowPower = (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || isMobile;

  var CYAN = new THREE.Color(0x6e767c);
  var ORANGE = new THREE.Color(0xff7a45);
  var WHITE = new THREE.Color(0xdff6fb);

  /* ================= Content: technologies, projects & skills ================= */
  var CATEGORIES = [
    { key:'lang',   label:'Languages',            color:CYAN,   dir:[ 1.0,  0.35,  0.30] },
    { key:'fw',     label:'Frameworks & Libraries',color:ORANGE, dir:[-1.0, -0.30,  0.35] },
    { key:'cloud',  label:'Cloud & DevOps',        color:CYAN,   dir:[ 0.30, 1.0,  -0.45] },
    { key:'data',   label:'Data & Protocols',      color:ORANGE, dir:[-0.35,-1.0,   0.30] },
    { key:'concept',label:'Practices & Concepts',  color:CYAN,   dir:[ 0.55,-0.35,  1.0 ] },
    { key:'proj',   label:'Projects',              color:ORANGE, dir:[-0.55, 0.30, -1.0 ] }
  ];

  var NODES = [
    // Languages
    { name:'JavaScript', cat:'lang', type:'Language', desc:'Core language for interactive, high-performance front-ends.' },
    { name:'TypeScript', cat:'lang', type:'Language', desc:'Type-safe development across large, maintainable codebases.' },
    { name:'Python',     cat:'lang', type:'Language', desc:'Backend services, scripting, and data-processing pipelines.' },
    { name:'Go',         cat:'lang', type:'Language', desc:'Lightweight, concurrent microservices and CLI tooling.' },
    { name:'SQL',        cat:'lang', type:'Language', desc:'Relational queries, schema design, and query tuning.' },
    { name:'C++',        cat:'lang', type:'Language', desc:'Performance-critical modules and systems-level code.' },
    // Frameworks & Libraries
    { name:'React',      cat:'fw', type:'Framework', desc:'Component-driven UIs, hooks, and production state management.', links:['Nebula'] },
    { name:'Three.js',   cat:'fw', type:'Library', desc:'WebGL scenes, shader work, and real-time 3D like this page.', links:['Nebula'] },
    { name:'Node.js',    cat:'fw', type:'Runtime', desc:'Event-driven backend services and REST/GraphQL APIs at scale.', links:['Pulse'] },
    { name:'Next.js',    cat:'fw', type:'Framework', desc:'Edge-rendered pages and full-stack React applications.', links:['Pulse'] },
    { name:'Django',     cat:'fw', type:'Framework', desc:"Rapid backend development with Python's batteries included." },
    { name:'Tailwind',   cat:'fw', type:'Library', desc:'Utility-first styling for fast, consistent interfaces.', links:['Orbit'] },
    // Cloud & DevOps
    { name:'AWS',        cat:'cloud', type:'Cloud', desc:'EC2, S3, Lambda, and IAM for scalable infrastructure.' },
    { name:'Docker',     cat:'cloud', type:'DevOps', desc:'Containerizing services for consistent builds everywhere.' },
    { name:'Kubernetes', cat:'cloud', type:'DevOps', desc:'Orchestrating containerized workloads at scale.' },
    { name:'Vercel',     cat:'cloud', type:'Platform', desc:'Edge deployment and previews for front-end apps.', links:['Orbit'] },
    { name:'Linux',      cat:'cloud', type:'OS', desc:'Shell scripting, process management, server administration.' },
    { name:'Git',        cat:'cloud', type:'Tooling', desc:'Branching strategy, review workflow, clean history.' },
    // Data & Protocols
    { name:'PostgreSQL', cat:'data', type:'Database', desc:'Relational schema design, indexing, and performance tuning.', links:['Pulse'] },
    { name:'MongoDB',    cat:'data', type:'Database', desc:'Document modeling for flexible, high-throughput apps.' },
    { name:'Redis',      cat:'data', type:'Database', desc:'In-memory caching and pub/sub for low-latency features.', links:['Signal'] },
    { name:'GraphQL',    cat:'data', type:'Protocol', desc:'Typed, client-driven data fetching across services.', links:['Orbit'] },
    { name:'WebSockets', cat:'data', type:'Protocol', desc:'Sub-second, bidirectional streaming for live features.', links:['Pulse','Signal'] },
    { name:'WebRTC',     cat:'data', type:'Protocol', desc:'Peer-to-peer channels for real-time collaboration.', links:['Signal'] },
    // Practices & Concepts
    { name:'System Design', cat:'concept', type:'Practice', desc:'Architecting scalable, fault-tolerant distributed systems.' },
    { name:'Testing',       cat:'concept', type:'Practice', desc:'Unit, integration, and end-to-end coverage for safe releases.' },
    { name:'Performance',   cat:'concept', type:'Practice', desc:'Bundle discipline, lazy loading, and rendering budgets.' },
    { name:'Accessibility', cat:'concept', type:'Practice', desc:'Interfaces that hold up for every user and input method.' },
    { name:'Security',      cat:'concept', type:'Practice', desc:'Threat-aware design, auth, and safe data handling.' },
    { name:'CRDT',          cat:'concept', type:'Concept', desc:'Conflict-free data structures for offline-first sync.', links:['Signal'] },
    // Projects
    { name:'Nebula', cat:'proj', type:'Project', desc:'A real-time 3D product configurator built with Three.js and React.' },
    { name:'Pulse',  cat:'proj', type:'Project', desc:'A live analytics dashboard streaming events over WebSockets.' },
    { name:'Orbit',  cat:'proj', type:'Project', desc:'A headless, edge-rendered commerce platform built for speed.' },
    { name:'Signal', cat:'proj', type:'Project', desc:'A CRDT-backed collaborative whiteboard for distributed teams.' }
  ];

  /* ================= Scene setup ================= */
  var scene = new THREE.Scene();
  var camera = new THREE.PerspectiveCamera(48, 1, 0.1, 100);
  camera.position.set(0, 0, 8.6);

  var renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
  renderer.setClearColor(0x000000, 0);
  var dpr = Math.min(window.devicePixelRatio || 1, isLowPower ? 1.4 : 2);
  renderer.setPixelRatio(dpr);
  container.appendChild(renderer.domElement);

  var networkGroup = new THREE.Group();
  scene.add(networkGroup);
  networkGroup.rotation.x = 0.18;

  /* ---- soft glow sprite texture (shared) ---- */
  function makeGlowTexture(){
    var size = 128;
    var c = document.createElement('canvas'); c.width = c.height = size;
    var ctx = c.getContext('2d');
    var g = ctx.createRadialGradient(size/2, size/2, 0, size/2, size/2, size/2);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.35, 'rgba(255,255,255,0.55)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, size, size);
    var tex = new THREE.CanvasTexture(c);
    return tex;
  }
  var glowTex = makeGlowTexture();

  /* ================= Cluster centers ================= */
  var clusterRadius = 3.15;
  CATEGORIES.forEach(function(cat){
    var v = new THREE.Vector3(cat.dir[0], cat.dir[1], cat.dir[2]).normalize().multiplyScalar(clusterRadius);
    cat.center = v;
    cat.namedNodes = [];
  });
  function catByKey(k){ for(var i=0;i<CATEGORIES.length;i++){ if(CATEGORIES[i].key===k) return CATEGORIES[i]; } return CATEGORIES[0]; }

  /* ================= Named nodes (hoverable) ================= */
  var namedGroup = new THREE.Group();
  networkGroup.add(namedGroup);
  var namedMeshes = [];   // parallel to NODES
  var adjacency = [];     // adjacency[i] = array of connected node indices

  NODES.forEach(function(n, i){
    var cat = catByKey(n.cat);
    var localCount = 0;
    NODES.forEach(function(m){ if(m.cat === n.cat) localCount++; });
    var idxInCat = cat.namedNodes.length;
    // fibonacci-ish spiral around the cluster center for even local spacing
    var golden = Math.PI * (3 - Math.sqrt(5));
    var y = 1 - (idxInCat / Math.max(1, localCount - 1)) * 2;
    var r = Math.sqrt(Math.max(0, 1 - y*y));
    var theta = golden * idxInCat;
    var local = new THREE.Vector3(Math.cos(theta)*r, y, Math.sin(theta)*r).multiplyScalar(1.05);
    var pos = cat.center.clone().add(local);

    var mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.052, 12, 12),
      new THREE.MeshBasicMaterial({ color:cat.color, transparent:true, opacity:0.95 })
    );
    mesh.position.copy(pos);

    var sprite = new THREE.Sprite(new THREE.SpriteMaterial({
      map:glowTex, color:cat.color, transparent:true, opacity:0.55,
      blending:THREE.AdditiveBlending, depthWrite:false
    }));
    sprite.scale.set(0.42, 0.42, 1);
    mesh.add(sprite);

    mesh.userData = { node:n, index:i, sprite:sprite, baseScale:1, phase:Math.random()*Math.PI*2 };
    namedGroup.add(mesh);
    namedMeshes.push(mesh);
    adjacency.push([]);
    cat.namedNodes.push(i);
  });

  function linkNodes(i, j){
    if(i===j) return;
    if(adjacency[i].indexOf(j) === -1) adjacency[i].push(j);
    if(adjacency[j].indexOf(i) === -1) adjacency[j].push(i);
  }
  function nodeIndexByName(name){
    for(var i=0;i<NODES.length;i++){ if(NODES[i].name===name) return i; }
    return -1;
  }

  // connect each named node to its ~2 nearest siblings in the same cluster
  CATEGORIES.forEach(function(cat){
    cat.namedNodes.forEach(function(i){
      var dists = cat.namedNodes
        .filter(function(j){ return j!==i; })
        .map(function(j){ return { j:j, d:namedMeshes[i].position.distanceTo(namedMeshes[j].position) }; })
        .sort(function(a,b){ return a.d - b.d; });
      dists.slice(0, 2).forEach(function(d){ linkNodes(i, d.j); });
    });
  });
  // curated cross-cluster links (tech -> project)
  NODES.forEach(function(n, i){
    (n.links || []).forEach(function(targetName){
      var j = nodeIndexByName(targetName);
      if(j !== -1) linkNodes(i, j);
    });
  });

  /* ================= Line materials (animated pulse shader) ================= */
  var vertexShader =
    'attribute vec3 aColor; attribute float aPhase;' +
    'varying vec3 vColor; varying float vPhase;' +
    'void main(){ vColor=aColor; vPhase=aPhase; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }';
  var fragmentShader =
    'precision mediump float; varying vec3 vColor; varying float vPhase;' +
    'uniform float uTime; uniform float uBase; uniform float uPulse; uniform float uSpeed;' +
    'void main(){' +
    '  float p = pow(0.5 + 0.5*sin(uTime*uSpeed + vPhase), 6.0);' +
    '  gl_FragColor = vec4(vColor, uBase + uPulse*p);' +
    '}';

  function makeLineMaterial(base, pulse, speed){
    return new THREE.ShaderMaterial({
      uniforms:{ uTime:{value:0}, uBase:{value:base}, uPulse:{value:pulse}, uSpeed:{value:speed} },
      vertexShader:vertexShader, fragmentShader:fragmentShader,
      transparent:true, depthWrite:false, blending:THREE.AdditiveBlending
    });
  }

  function buildLineSegments(pairs, colorFn, material){
    var positions = new Float32Array(pairs.length * 6);
    var colors = new Float32Array(pairs.length * 6);
    var phases = new Float32Array(pairs.length * 2);
    pairs.forEach(function(pr, idx){
      var a = pr.a, b = pr.b, col = colorFn(pr);
      positions.set([a.x,a.y,a.z, b.x,b.y,b.z], idx*6);
      colors.set([col.r,col.g,col.b, col.r,col.g,col.b], idx*6);
      var ph = pr.phase != null ? pr.phase : Math.random()*Math.PI*2;
      phases[idx*2] = ph; phases[idx*2+1] = ph;
    });
    var geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geo.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
    geo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
    return new THREE.LineSegments(geo, material);
  }

  /* ---- core lines: backbone between clusters + named-node links ---- */
  var corePairs = [];
  for(var ci=0; ci<CATEGORIES.length; ci++){
    for(var cj=ci+1; cj<CATEGORIES.length; cj++){
      corePairs.push({ a:CATEGORIES[ci].center, b:CATEGORIES[cj].center, colorMix:0.15 });
    }
  }
  var namedPairSet = {};
  adjacency.forEach(function(list, i){
    list.forEach(function(j){
      var key = Math.min(i,j)+'-'+Math.max(i,j);
      if(namedPairSet[key]) return;
      namedPairSet[key] = true;
      corePairs.push({ a:namedMeshes[i].position, b:namedMeshes[j].position, colorMix:1 });
    });
  });
  var coreMat = makeLineMaterial(0.16, 0.55, 0.9);
  var coreColorOf = function(pr){ return WHITE.clone().lerp(CYAN, 0.4).multiplyScalar(0.5 + 0.5*pr.colorMix); };
  var coreLines = buildLineSegments(corePairs, coreColorOf, coreMat);
  networkGroup.add(coreLines);

  /* ================= Ambient filler nodes (the "thousands") ================= */
  var fillerCount = isLowPower ? 1100 : (isMobile ? 1600 : 2800);
  var fPositions = new Float32Array(fillerCount * 3);
  var fColors = new Float32Array(fillerCount * 3);
  var fillerMeta = []; // { pos, catIndex|null }

  for(var f=0; f<fillerCount; f++){
    var assignToCluster = Math.random() < 0.82;
    var pos, col;
    if(assignToCluster){
      var cat = CATEGORIES[(f + Math.floor(Math.random()*CATEGORIES.length)) % CATEGORIES.length];
      var dir = new THREE.Vector3(Math.random()-0.5, Math.random()-0.5, Math.random()-0.5).normalize();
      var rad = 0.5 + Math.random()*Math.random()*2.1;
      pos = cat.center.clone().add(dir.multiplyScalar(rad));
      col = cat.color.clone().lerp(WHITE, 0.25 + Math.random()*0.35).multiplyScalar(0.85);
      fillerMeta.push({ pos:pos, cat:cat });
    } else {
      var dir2 = new THREE.Vector3(Math.random()-0.5, Math.random()-0.5, Math.random()-0.5).normalize();
      var rad2 = 2.2 + Math.random()*3.6;
      pos = dir2.multiplyScalar(rad2);
      col = WHITE.clone().lerp(CYAN, 0.3).multiplyScalar(0.4);
      fillerMeta.push({ pos:pos, cat:null });
    }
    fPositions.set([pos.x,pos.y,pos.z], f*3);
    fColors.set([col.r,col.g,col.b], f*3);
  }

  var fGeo = new THREE.BufferGeometry();
  fGeo.setAttribute('position', new THREE.BufferAttribute(fPositions, 3));
  fGeo.setAttribute('color', new THREE.BufferAttribute(fColors, 3));
  var fMat = new THREE.PointsMaterial({
    size:0.052, map:glowTex, vertexColors:true, transparent:true, opacity:0.85,
    blending:THREE.AdditiveBlending, depthWrite:false, sizeAttenuation:true
  });
  var fillerPoints = new THREE.Points(fGeo, fMat);
  networkGroup.add(fillerPoints);

  /* ---- filler connections: to nearest named node in-cluster + chained neighbors ---- */
  var fillerPairs = [];
  var prevInCluster = {};
  fillerMeta.forEach(function(m, i){
    if(m.cat){
      // link to nearest named node in this cluster (cheap: small cluster sizes)
      if(Math.random() < 0.55){
        var best = null, bestD = Infinity;
        m.cat.namedNodes.forEach(function(ni){
          var d = m.pos.distanceTo(namedMeshes[ni].position);
          if(d < bestD){ bestD = d; best = namedMeshes[ni].position; }
        });
        if(best) fillerPairs.push({ a:m.pos, b:best, colorMix:0 });
      }
      // chain to previous filler point in the same cluster
      var key = m.cat.key;
      if(prevInCluster[key] !== undefined && Math.random() < 0.5){
        fillerPairs.push({ a:m.pos, b:fillerMeta[prevInCluster[key]].pos, colorMix:0 });
      }
      prevInCluster[key] = i;
    } else if(i > 0 && Math.random() < 0.4){
      fillerPairs.push({ a:m.pos, b:fillerMeta[i-1].pos, colorMix:0 });
    }
  });
  var fillerMat = makeLineMaterial(0.045, 0.16, 1.6);
  var fillerColorOf = function(){ return WHITE.clone().lerp(CYAN, 0.5).multiplyScalar(0.5); };
  var fillerLines = buildLineSegments(fillerPairs, fillerColorOf, fillerMat);
  networkGroup.add(fillerLines);

  document.getElementById('neuralNodeCount').textContent = (NODES.length + fillerCount).toLocaleString();
  document.getElementById('neuralLinkCount').textContent = (corePairs.length + fillerPairs.length).toLocaleString();

  /* ================= Hover highlight lines ================= */
  var highlightMat = new THREE.LineBasicMaterial({ color:0x9aa4ab, transparent:true, opacity:0.9, blending:THREE.AdditiveBlending, depthWrite:false });
  var highlightObj = null;
  function setHighlight(index){
    if(highlightObj){ networkGroup.remove(highlightObj); highlightObj.geometry.dispose(); highlightObj = null; }
    if(index == null) return;
    var positions = [];
    adjacency[index].forEach(function(j){
      var a = namedMeshes[index].position, b = namedMeshes[j].position;
      positions.push(a.x,a.y,a.z, b.x,b.y,b.z);
    });
    if(!positions.length) return;
    var geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(positions), 3));
    highlightObj = new THREE.LineSegments(geo, highlightMat);
    networkGroup.add(highlightObj);
  }

  /* ================= Tooltip & interaction ================= */
  var tooltip = document.getElementById('neuralTooltip');
  var ntType = document.getElementById('ntType');
  var ntName = document.getElementById('ntName');
  var ntDesc = document.getElementById('ntDesc');
  var ntLinks = document.getElementById('ntLinks');
  var hint = document.getElementById('neuralHint');

  var hoveredIndex = null;
  function showTooltip(index, clientX, clientY){
    var n = NODES[index];
    var cat = catByKey(n.cat);
    tooltip.hidden = false;
    tooltip.classList.toggle('is-cyan', cat.color === CYAN);
    ntType.textContent = n.type + ' \u2014 ' + cat.label;
    ntName.textContent = n.name;
    ntDesc.textContent = n.desc;
    var connectedNames = adjacency[index].map(function(j){ return NODES[j].name; });
    ntLinks.textContent = connectedNames.length ? ('Connected: ' + connectedNames.slice(0,4).join(', ')) : '';
    positionTooltip(clientX, clientY);
    if(hint) hint.style.opacity = '0';
  }
  function positionTooltip(clientX, clientY){
    var r = stage.getBoundingClientRect();
    var x = clientX - r.left, y = clientY - r.top;
    var tw = tooltip.offsetWidth || 230, th = tooltip.offsetHeight || 110;
    x = Math.min(Math.max(x + 18, 8), r.width - tw - 8);
    y = Math.min(Math.max(y - th/2, 8), r.height - th - 8);
    tooltip.style.left = x + 'px';
    tooltip.style.top = y + 'px';
  }
  function hideTooltip(){
    tooltip.hidden = true;
    if(hint) hint.style.opacity = '';
  }
  function setHovered(index, clientX, clientY){
    if(index === hoveredIndex) { if(index != null) positionTooltip(clientX, clientY); return; }
    hoveredIndex = index;
    setHighlight(index);
    if(index == null){ hideTooltip(); } else { showTooltip(index, clientX, clientY); }
  }

  var raycaster = new THREE.Raycaster();
  raycaster.params.Points && (raycaster.params.Points.threshold = 0.08);
  var ndc = new THREE.Vector2();
  function pickNode(clientX, clientY){
    var r = container.getBoundingClientRect();
    ndc.x = ((clientX - r.left) / r.width) * 2 - 1;
    ndc.y = -((clientY - r.top) / r.height) * 2 + 1;
    raycaster.setFromCamera(ndc, camera);
    var hits = raycaster.intersectObjects(namedMeshes, false);
    return hits.length ? hits[0].object.userData.index : null;
  }

  /* ---- drag to rotate (pointer events cover mouse + touch) ---- */
  var dragging = false, dragMoved = false, lastX = 0, lastY = 0;
  var rotVX = 0, rotVY = 0;

  container.addEventListener('pointerdown', function(e){
    dragging = true; dragMoved = false;
    lastX = e.clientX; lastY = e.clientY;
    stage.classList.add('grabbing');
    try{ container.setPointerCapture(e.pointerId); }catch(err){}
  });
  container.addEventListener('pointermove', function(e){
    if(dragging){
      var dx = e.clientX - lastX, dy = e.clientY - lastY;
      if(Math.abs(dx) + Math.abs(dy) > 3) dragMoved = true;
      rotVY = dx * 0.006; rotVX = dy * 0.006;
      networkGroup.rotation.y += rotVY;
      networkGroup.rotation.x = Math.max(-1.1, Math.min(1.1, networkGroup.rotation.x + rotVX));
      lastX = e.clientX; lastY = e.clientY;
      if(!isTouch) setHovered(pickNode(e.clientX, e.clientY), e.clientX, e.clientY);
    } else if(!isTouch){
      setHovered(pickNode(e.clientX, e.clientY), e.clientX, e.clientY);
    }
  });
  window.addEventListener('pointerup', function(e){
    if(dragging && isTouch && !dragMoved){
      var idx = pickNode(e.clientX, e.clientY);
      setHovered(idx === hoveredIndex ? null : idx, e.clientX, e.clientY);
    }
    dragging = false;
    stage.classList.remove('grabbing');
  });
  container.addEventListener('pointerleave', function(){
    if(!isTouch && !dragging) setHovered(null);
  });

  /* ================= Resize ================= */
  var lastNetW = 0;
  function resize(){
    var w = container.clientWidth || stage.clientWidth;
    var h = container.clientHeight || stage.clientHeight;
    if(!w || !h) return;
    /* Ignore height-only changes (mobile address bar show/hide) to avoid
       needless re-renders while scrolling. */
    if(w === lastNetW) return;
    lastNetW = w;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  }
  var netResizeRAF = null;
  window.addEventListener('resize', function(){
    if(netResizeRAF) cancelAnimationFrame(netResizeRAF);
    netResizeRAF = requestAnimationFrame(resize);
  }, { passive: true });
  resize();

  /* ================= Visibility-gated render loop ================= */
  var running = false;
  var clock = new THREE.Clock();
  var visObserver = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      if(entry.isIntersecting && !running){ running = true; clock.start(); requestAnimationFrame(tick); }
      else if(!entry.isIntersecting){ running = false; }
    });
  }, { threshold:0.08 });
  visObserver.observe(stage);

  function tick(){
    if(!running) return;
    requestAnimationFrame(tick);
    var t = clock.getElapsedTime();

    if(!reduceMotion){
      coreMat.uniforms.uTime.value = t;
      fillerMat.uniforms.uTime.value = t;
      if(!dragging) networkGroup.rotation.y += 0.0012;

      namedMeshes.forEach(function(m){
        var d = m.userData;
        var pulse = 1 + Math.sin(t*1.6 + d.phase) * 0.12;
        var hoveredScale = (d.index === hoveredIndex) ? 1.7 : 1;
        m.scale.setScalar(pulse * hoveredScale);
        d.sprite.material.opacity = (d.index === hoveredIndex ? 0.9 : 0.5) + Math.sin(t*1.6+d.phase)*0.08;
      });
    }

    renderer.render(scene, camera);
  }
})();
  (function(){
    "use strict";
    var overlay = document.getElementById('caseModalOverlay');
    var body = document.getElementById('caseModalBody');
    var closeBtn = document.getElementById('caseModalClose');
    var backBtn = document.getElementById('caseModalBack');
    if(!overlay || !body || !closeBtn) return;
    var lastTrigger = null;

    function openCase(tplId, trigger){
      var tpl = document.getElementById(tplId);
      if(!tpl) return;
      lastTrigger = trigger || null;
      body.innerHTML = '';
      var clone = tpl.content.cloneNode(true);
      clone.querySelectorAll('.reveal').forEach(function(el){
        el.classList.add('in-view');
      });
      body.appendChild(clone);
      body.scrollTop = 0;
      overlay.classList.add('active');
      document.body.classList.add('case-modal-open');
      closeBtn.focus();
    }

    function closeCase(){
      overlay.classList.remove('active');
      document.body.classList.remove('case-modal-open');
      if(lastTrigger && typeof lastTrigger.focus === 'function'){ lastTrigger.focus(); }
    }

    document.querySelectorAll('[data-case-open]').forEach(function(btn){
      btn.addEventListener('click', function(){
        openCase(btn.getAttribute('data-case-open'), btn);
      });
    });

    closeBtn.addEventListener('click', closeCase);
    if(backBtn){ backBtn.addEventListener('click', closeCase); }
    overlay.addEventListener('click', function(e){
      if(e.target === overlay){ closeCase(); }
    });
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape' && overlay.classList.contains('active')){ closeCase(); }
    });
  })();
